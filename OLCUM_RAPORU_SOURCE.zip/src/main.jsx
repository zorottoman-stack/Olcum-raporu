import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import ExcelJS from 'exceljs';
import { FileUp, FileSpreadsheet, Download, Plus, Trash2, CheckCircle2, AlertTriangle, Settings2, ClipboardList, ArrowRightLeft } from 'lucide-react';
import './style.css';

const STANDARD_FIELDS = [
  { key: 'motor', label: 'Motor seri no', aliases: ['motor seri no', 'motor seri numarası', 'seri no', 'serial number'] },
  { key: 'drawing', label: 'Teknik resim sıra no', aliases: ['teknik resim sıra no', 'resim sıra no', 'sıra no', 'drawing no'] },
  { key: 'tool', label: 'Kontrol aleti', aliases: ['kontrol aleti', 'ölçüm aleti', 'ölçü aleti'] },
  { key: 'description', label: 'Tanım', aliases: ['tanım', 'ölçüm noktası', 'özellik', 'characteristic'] },
  { key: 'nominal', label: 'Nominal ölçü', aliases: ['nominal ölçü', 'nominal', 'ölçü', 'nominal value'] },
  { key: 'tolerance', label: 'Ölçü - tolerans', aliases: ['ölçü - tolerans', 'ölçü-tolerans', 'tolerans', 'tolerance'] },
  { key: 'measured', label: 'Ölçülen değer', aliases: ['ölçülen değer', 'ölçüm değeri', 'gerçek değer', 'actual value'] },
  { key: 'result', label: 'Sonuç', aliases: ['sonuç', 'uygunluk', 'result', 'pass/fail'] }
];
const norm = (v) => String(v ?? '').toLocaleLowerCase('tr-TR').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
const textOf = (v) => v == null ? '' : (typeof v === 'object' && v.text ? v.text : String(v)).trim();
const asNumber = (v) => {
  if (v == null || String(v).trim() === '') return NaN;
  const n = Number(String(v).replace(',', '.').replace(/\s/g, ''));
  return Number.isFinite(n) ? n : NaN;
};
function getTolerance(t) {
  const s = String(t ?? '').replace(',', '.');
  const m = s.match(/(?:±\s*)?([0-9]*\.?[0-9]+)/);
  return m ? Number(m[1]) : NaN;
}
function detectField(header) {
  const h = norm(header);
  for (const field of STANDARD_FIELDS) {
    if (field.aliases.some(a => h === norm(a) || h.includes(norm(a)))) return field;
  }
  return null;
}

function App() {
  const [templateName, setTemplateName] = useState('');
  const [workbookBytes, setWorkbookBytes] = useState(null);
  const [sheetName, setSheetName] = useState('');
  const [headers, setHeaders] = useState([]);
  const [headerRow, setHeaderRow] = useState(1);
  const [mapping, setMapping] = useState({});
  const [form, setForm] = useState({ motor: '', drawing: '', tool: 'Mikrometre', description: '', nominal: '6', tolerance: '±0,010 mm', measured: '5,998', result: '' });
  const [records, setRecords] = useState([]);
  const [notice, setNotice] = useState('Başlamak için bir Excel şablonu yükleyin veya manuel kayıt girin.');
  const [busy, setBusy] = useState(false);

  const resultPreview = useMemo(() => {
    const nominal = asNumber(form.nominal);
    const measured = asNumber(form.measured);
    const tol = getTolerance(form.tolerance);
    if (!Number.isFinite(nominal) || !Number.isFinite(measured) || !Number.isFinite(tol)) return '';
    return measured >= nominal - tol && measured <= nominal + tol ? 'Uygun' : 'Uygunsuz';
  }, [form.nominal, form.measured, form.tolerance]);

  const setValue = (key, value) => setForm(old => ({ ...old, [key]: value }));

  async function loadTemplate(file) {
    if (!file) return;
    setBusy(true);
    try {
      const bytes = await file.arrayBuffer();
      const wb = new ExcelJS.Workbook();
      await wb.xlsx.load(bytes);
      const ws = wb.worksheets[0];
      if (!ws) throw new Error('Dosyada çalışma sayfası bulunamadı.');
      let best = { row: 1, values: [], score: -1 };
      const maxRows = Math.min(ws.rowCount || 1, 30);
      for (let r = 1; r <= maxRows; r++) {
        const values = [];
        ws.getRow(r).eachCell({ includeEmpty: false }, (cell, col) => { values[col - 1] = textOf(cell.value); });
        const score = values.filter(v => String(v || '').trim()).length;
        if (score > best.score) best = { row: r, values, score };
      }
      const detected = best.values.map((v, i) => ({ col: i + 1, header: String(v || '').trim() })).filter(x => x.header);
      if (!detected.length) throw new Error('Başlık bulunamadı. Dosyada başlık satırı olan bir Excel deneyin.');
      const nextMap = {};
      detected.forEach(h => { const f = detectField(h.header); if (f && !nextMap[f.key]) nextMap[f.key] = h.col; });
      setWorkbookBytes(bytes);
      setTemplateName(file.name);
      setSheetName(ws.name);
      setHeaders(detected);
      setHeaderRow(best.row);
      setMapping(nextMap);
      setNotice(`${file.name} yüklendi. "${ws.name}" sayfasında ${best.row}. satır başlık adayı olarak seçildi. Eşleştirmeleri kontrol edin.`);
    } catch (e) {
      setNotice(`Dosya okunamadı: ${e.message || e}`);
    } finally { setBusy(false); }
  }

  function addRecord() {
    const record = { ...form, result: form.result || resultPreview || 'Kontrol gerekli', id: Date.now() + Math.random() };
    if (!record.motor && !record.drawing && !record.description && !record.measured) {
      setNotice('Lütfen en azından motor seri no, resim sıra no, tanım veya ölçülen değer alanlarından birini doldurun.');
      return;
    }
    setRecords(old => [record, ...old]);
    setNotice('Ölçüm kaydı listeye eklendi.');
  }

  async function exportRecord(record) {
    setBusy(true);
    try {
      let wb = new ExcelJS.Workbook();
      let ws;
      if (workbookBytes) {
        await wb.xlsx.load(workbookBytes.slice(0));
        ws = wb.getWorksheet(sheetName) || wb.worksheets[0];
      } else {
        ws = wb.addWorksheet('Ölçüm Raporu');
        ws.addRow(['Motor seri no', 'Teknik resim sıra no', 'Kontrol aleti', 'Tanım', 'Nominal ölçü', 'Ölçü - tolerans', 'Ölçülen değer', 'Sonuç']);
        headers.splice(0, headers.length, ...['Motor seri no', 'Teknik resim sıra no', 'Kontrol aleti', 'Tanım', 'Nominal ölçü', 'Ölçü - tolerans', 'Ölçülen değer', 'Sonuç'].map((header, i) => ({ col: i + 1, header })));
        mapping.motor = 1; mapping.drawing = 2; mapping.tool = 3; mapping.description = 4; mapping.nominal = 5; mapping.tolerance = 6; mapping.measured = 7; mapping.result = 8;
      }
      const values = { motor: record.motor, drawing: record.drawing, tool: record.tool, description: record.description, nominal: record.nominal, tolerance: record.tolerance, measured: record.measured, result: record.result || resultPreview };
      const mappedCols = Object.entries(mapping).filter(([key, col]) => values[key] !== undefined && col);
      const rowNumber = Math.max(headerRow + 1, (ws.actualRowCount || ws.rowCount || headerRow) + 1);
      const row = ws.getRow(rowNumber);
      mappedCols.forEach(([key, col]) => { row.getCell(Number(col)).value = values[key] ?? ''; });
      row.commit();
      const buffer = await wb.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const safe = (record.motor || record.drawing || record.description || 'olcum-raporu').replace(/[^a-z0-9-_]+/gi, '-').replace(/^-|-$/g, '');
      a.href = url; a.download = `${safe || 'olcum-raporu'}.xlsx`; a.click();
      URL.revokeObjectURL(url);
      setNotice('Excel dosyası oluşturuldu. Şablonun biçimlendirmesini kontrol ederek kullanın.');
    } catch (e) { setNotice(`Excel oluşturulamadı: ${e.message || e}`); }
    finally { setBusy(false); }
  }

  async function importDataFile(file) {
    if (!file) return;
    try {
      const ext = file.name.toLowerCase().split('.').pop();
      let rows = [];
      if (ext === 'csv' || ext === 'txt') {
        const txt = await file.text();
        const lines = txt.split(/\r?\n/).filter(Boolean);
        const delimiter = lines[0]?.includes(';') ? ';' : lines[0]?.includes('\t') ? '\t' : ',';
        rows = lines.map(line => line.split(delimiter).map(x => x.trim().replace(/^"|"$/g, '')));
      } else if (ext === 'xlsx' || ext === 'xlsm') {
        const wb = new ExcelJS.Workbook(); await wb.xlsx.load(await file.arrayBuffer());
        const ws = wb.worksheets[0];
        ws.eachRow({ includeEmpty: false }, row => rows.push(row.values.slice(1).map(textOf)));
      } else throw new Error('Desteklenen biçimler: XLSX, CSV ve TXT.');
      if (rows.length < 2) throw new Error('Aktarım için başlık satırı ve en az bir veri satırı gerekir.');
      const sourceHeaders = rows[0].map(String);
      const sourceMap = {};
      sourceHeaders.forEach((h, i) => { const f = detectField(h); if (f && sourceMap[f.key] === undefined) sourceMap[f.key] = i; });
      const imported = rows.slice(1).filter(r => r.some(v => String(v ?? '').trim())).map((r, idx) => {
        const obj = { id: Date.now() + idx + Math.random() };
        STANDARD_FIELDS.forEach(f => { obj[f.key] = sourceMap[f.key] === undefined ? '' : String(r[sourceMap[f.key]] ?? ''); });
        if (!obj.result) {
          const n = asNumber(obj.nominal), m = asNumber(obj.measured), t = getTolerance(obj.tolerance);
          obj.result = Number.isFinite(n) && Number.isFinite(m) && Number.isFinite(t) ? (m >= n-t && m <= n+t ? 'Uygun' : 'Uygunsuz') : 'Kontrol gerekli';
        }
        return obj;
      });
      setRecords(old => [...imported, ...old]);
      setNotice(`${imported.length} kayıt içe aktarıldı. Alan eşleştirmelerini ve sonuçları kontrol edin.`);
    } catch (e) { setNotice(`Aktarım başarısız: ${e.message || e}`); }
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-mark"><ClipboardList size={22}/></div>
      <div><div className="brand-title">Ölçüm Raporu</div><div className="brand-sub">Excel şablonu · Akıllı veri girişi</div></div>
      <span className="top-pill">MVP</span>
    </header>
    <main>
      <section className="hero">
        <div className="eyebrow">KALİTE KONTROL</div>
        <h1>Ölçüm raporunu<br/><span>kolayca oluştur.</span></h1>
        <p>Excel şablonunu yükle, alanları kontrol et, ölçüm verilerini gir veya dosyadan aktar. Her kaydı ayrı bir Excel dosyası olarak dışa aktar.</p>
      </section>

      <section className="panel">
        <div className="section-heading"><div className="section-icon"><FileUp size={19}/></div><div><h2>1. Excel şablonu</h2><p>Başlıklar otomatik taranır; eşleştirmeleri kontrol et.</p></div></div>
        <label className="upload-box">
          <input type="file" accept=".xlsx,.xlsm" onChange={e => loadTemplate(e.target.files?.[0])}/>
          <FileSpreadsheet size={26}/><strong>{templateName || 'Excel şablonunu seç'}</strong><span>{busy ? 'İşleniyor…' : 'XLSX veya XLSM · İlk çalışma sayfası analiz edilir'}</span>
        </label>
        {headers.length > 0 && <div className="mapping-area">
          <div className="mapping-title"><Settings2 size={17}/> Alan eşleştirmesi <span>{sheetName} · başlık satırı {headerRow}</span></div>
          <div className="mapping-list">
            {STANDARD_FIELDS.map(f => <div className="mapping-row" key={f.key}><label>{f.label}</label><select value={mapping[f.key] || ''} onChange={e => setMapping(old => ({ ...old, [f.key]: e.target.value ? Number(e.target.value) : undefined }))}><option value="">Eşleştirme yok</option>{headers.map(h => <option key={h.col} value={h.col}>{h.header}</option>)}</select></div>)}
          </div>
          <p className="hint"><AlertTriangle size={15}/> Karmaşık şablonlarda dışa aktarılan satırın konumunu ve biçimini kontrol edin.</p>
        </div>}
      </section>

      <section className="panel">
        <div className="section-heading"><div className="section-icon"><ClipboardList size={19}/></div><div><h2>2. Ölçüm bilgileri</h2><p>Her kayıt ayrı bir rapora dönüşür.</p></div></div>
        <div className="form-grid">
          <div className="field"><label>Motor seri no</label><input value={form.motor} onChange={e=>setValue('motor',e.target.value)} placeholder="Örn. 0000000008013…"/></div>
          <div className="field"><label>Teknik resim sıra no</label><input value={form.drawing} onChange={e=>setValue('drawing',e.target.value)} placeholder="Örn. K35"/></div>
          <div className="field"><label>Kontrol aleti</label><input value={form.tool} onChange={e=>setValue('tool',e.target.value)} placeholder="Mikrometre"/></div>
          <div className="field"><label>Tanım</label><input value={form.description} onChange={e=>setValue('description',e.target.value)} placeholder="Vidalı mil çapı"/></div>
          <div className="field"><label>Nominal ölçü (mm)</label><input inputMode="decimal" value={form.nominal} onChange={e=>setValue('nominal',e.target.value)} placeholder="6,000"/></div>
          <div className="field"><label>Ölçü - tolerans</label><input value={form.tolerance} onChange={e=>setValue('tolerance',e.target.value)} placeholder="±0,010 mm"/></div>
          <div className="field"><label>Ölçülen değer (mm)</label><input inputMode="decimal" value={form.measured} onChange={e=>setValue('measured',e.target.value)} placeholder="5,998"/></div>
          <div className="field"><label>Sonuç</label><select value={form.result} onChange={e=>setValue('result',e.target.value)}><option value="">Otomatik hesapla</option><option value="Uygun">Uygun</option><option value="Uygunsuz">Uygunsuz</option><option value="Kontrol gerekli">Kontrol gerekli</option></select></div>
        </div>
        <div className={`result-preview ${resultPreview === 'Uygun' ? 'good' : resultPreview === 'Uygunsuz' ? 'bad' : 'neutral'}`}>
          {resultPreview === 'Uygun' ? <CheckCircle2 size={18}/> : <AlertTriangle size={18}/>}
          <div><strong>{resultPreview || 'Sonuç hesaplanamıyor'}</strong><span>{resultPreview ? `Kabul aralığı: ${Number(asNumber(form.nominal)-getTolerance(form.tolerance)).toLocaleString('tr-TR')} – ${Number(asNumber(form.nominal)+getTolerance(form.tolerance)).toLocaleString('tr-TR')} mm` : 'Nominal değer, tolerans ve ölçülen değeri kontrol edin.'}</span></div>
        </div>
        <button className="primary-btn" onClick={addRecord}><Plus size={18}/> Kaydı listeye ekle</button>
      </section>

      <section className="panel">
        <div className="section-heading"><div className="section-icon"><ArrowRightLeft size={19}/></div><div><h2>3. Dosyadan aktar</h2><p>Başlık içeren CSV, TXT veya XLSX dosyaları.</p></div></div>
        <label className="upload-box compact">
          <input type="file" accept=".xlsx,.xlsm,.csv,.txt" onChange={e => importDataFile(e.target.files?.[0])}/>
          <FileUp size={22}/><strong>Ölçüm dosyasını seç</strong><span>İlk satırda başlıklar bulunmalıdır.</span>
        </label>
      </section>

      <section className="panel">
        <div className="section-heading"><div className="section-icon"><FileSpreadsheet size={19}/></div><div><h2>4. Rapor kayıtları</h2><p>{records.length} kayıt listede</p></div></div>
        {records.length === 0 ? <div className="empty-state"><FileSpreadsheet size={30}/><strong>Henüz kayıt yok</strong><span>Formu doldurup “Kaydı listeye ekle” düğmesine bas.</span></div> :
          <div className="record-list">{records.map(r => <div className="record-card" key={r.id}><div className="record-info"><strong>{r.motor || r.drawing || r.description || 'Ölçüm kaydı'}</strong><span>{r.description || 'Tanım belirtilmedi'} · {r.measured || '—'} mm</span><em className={r.result === 'Uygun' ? 'good-text' : r.result === 'Uygunsuz' ? 'bad-text' : ''}>{r.result || 'Kontrol gerekli'}</em></div><button className="icon-btn export-btn" title="Excel indir" onClick={() => exportRecord(r)}><Download size={18}/></button><button className="icon-btn delete-btn" title="Kaydı sil" onClick={() => setRecords(old => old.filter(x => x.id !== r.id))}><Trash2 size={17}/></button></div>)}</div>}
        {records.length > 0 && <button className="secondary-btn" onClick={async () => { for (const r of records) await exportRecord(r); }}>Tüm kayıtları ayrı ayrı indir</button>}
      </section>
      <div className="notice" role="status">{notice}</div>
      <p className="footnote">Veriler bu cihazda işlenir. Üretilen raporları kullanmadan önce toleransları, hücre eşleştirmelerini ve Excel görünümünü doğrulayın.</p>
    </main>
  </div>;
}

createRoot(document.getElementById('root')).render(<App/>);