# Ölçüm Raporu Oluşturucu

Türkçe arayüzlü, web/PWA yaklaşımıyla hazırlanan ve GitHub Actions üzerinden Android debug APK olarak derlenebilen başlangıç projesi.

## Özellikler
- XLSX şablonu yükleme ve çalışma sayfası başlıklarını tarama
- Tanınan başlıklara göre dinamik form oluşturma
- Motor seri numarası, teknik resim sıra no, kontrol aleti, tanım, nominal ölçü, tolerans, ölçülen değer ve sonuç alanları
- Nominal değer ve ± tolerans girilmişse temel uygunluk hesabı
- XLSX/CSV/TXT dosyasından basit satır aktarımı
- Her kayıt için ayrı XLSX dışa aktarma
- GitHub Actions ile Android debug APK derleme

## Yerel çalıştırma
Node.js 20+ gerekir:
```bash
npm install
npm run dev
```

## Android APK
1. `OLCUM_RAPORU_SOURCE.zip` dosyasını GitHub deposunun köküne yükleyin.
2. `.github/workflows/build-olcum-raporu-apk.yml` dosyasını belirtilen konumda ayrı olarak yükleyin.
3. GitHub > Actions > **Build Ölçüm Raporu APK** > **Run workflow** yolunu izleyin.
4. İşlem bitince `olcum-raporu-debug-apk` artifact'ini indirin.

## Önemli notlar
- Bu başlangıç sürümü Excel başlıklarını ve ilk satırlardaki alanları otomatik analiz eder; her dosyada doğru hücre eşlemesini garanti edemez. Dışa aktarmadan önce alanları kontrol edin.
- Excel şablonundaki karmaşık birleştirilmiş hücreler, resimler, makrolar, baskı alanları ve gelişmiş biçimlendirmeler tüm durumlarda eksiksiz korunmayabilir. Gerçek şablonlarla test edilerek eşleştirme kuralları geliştirilmeli.
- Ölçüm toleransları birim ve işaret açısından doğrulanmalıdır. `±0,010 mm` değeri uygulamada nominal ölçünün etrafında ±0,010 mm olarak yorumlanır.
- Bu sürüm raporu cihazda oluşturur; sunucuya veri göndermez.
